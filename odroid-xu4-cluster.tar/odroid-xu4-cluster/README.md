# ODROID XU4 Mini Cluster

This repository contains fils, configuration, tools, and libraries used for building a small compute cluster from ODROID XU4 single board computers, as documented at the [DIY Big Data project page](http://diybigdata.net/odroid-xu4-cluster/). 
