# Hadoop Configuration for ODROID XU4 Cluster

These configuration files should be placed in the `$HADOOP_HOME/etc/hadoop/` directory of your Hadoop configuration. See the [DIY Big Data project page](http://diybigdata.net/odroid-xu4-cluster/) for more information.