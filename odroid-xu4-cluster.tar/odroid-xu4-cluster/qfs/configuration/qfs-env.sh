#!/bin/bash

#
# QFS specific environment variables
#

export QFS_LOGS_DIR=/data/qfs/logs
